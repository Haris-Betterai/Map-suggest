# 🗺️ MapTiler Address Autocomplete

A production-ready Flask web application that provides real-time address auto-suggestions (autocomplete) similar to Google Maps, using the MapTiler Geocoding API.

## ✨ Features

- **Real-time Autocomplete**: Google Maps-like address suggestions as you type
- **Debounced API Calls**: Optimized with 300ms debounce to reduce unnecessary requests
- **Keyboard Navigation**: Full support for Arrow Up/Down, Enter, and Escape keys
- **Modern UI**: Clean, professional design with smooth animations
- **Responsive**: Works perfectly on mobile and desktop
- **Loading States**: Visual feedback with loading spinner
- **Error Handling**: Graceful handling of API failures
- **Highlight Matching**: Emphasizes typed text in results
- **XSS Protection**: All user input is properly escaped

## 🚀 Quick Start

### Prerequisites

- Python 3.7 or higher
- pip (Python package installer)

### Installation

1. **Clone or navigate to the project directory**
   ```bash
   cd "d:\Better. AI\Maps"
   ```

2. **Create a virtual environment (recommended)**
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate
   ```

3. **Install dependencies**
   ```powershell
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```powershell
   python app.py
   ```

5. **Open your browser**
   Navigate to: `http://localhost:5000`

## 📁 Project Structure

```
Maps/
├── app.py                 # Flask backend with /autocomplete endpoint
├── requirements.txt       # Python dependencies
├── templates/
│   └── index.html        # Main HTML template
└── static/
    ├── style.css         # Modern CSS styling
    └── script.js         # Autocomplete logic with debounce & keyboard nav
```

## 🔧 API Configuration

The MapTiler Geocoding API is configured with:

- **API Key**: `DVL1VXFhlCuGm9uEgtP9`
- **Endpoint**: `https://api.maptiler.com/geocoding/{query}.json`
- **Parameters**:
  - `limit=5` - Maximum 5 suggestions
  - `country=pk` - Restricted to Pakistan
  - `autocomplete=true` - Enable autocomplete mode

### ⚠️ API Key Security

**IMPORTANT**: The API key is currently hardcoded for development. For production:

1. Use environment variables:
   ```python
   import os
   MAPTILER_API_KEY = os.getenv('MAPTILER_API_KEY')
   ```

2. Restrict API key usage in MapTiler dashboard to:
   - `http://localhost:5000/*` (development)
   - Your production domain

3. Never commit API keys to public repositories

## 🎯 Usage

1. Start typing an address in the search box
2. Suggestions will appear after 300ms
3. Use **Arrow Down/Up** to navigate suggestions
4. Press **Enter** to select a suggestion
5. Press **Escape** to close the dropdown
6. Click on any suggestion to select it

## 🛠️ Technical Details

### Backend (Flask)

- **Route**: `/autocomplete`
- **Method**: GET
- **Query Parameter**: `q` (search query)
- **Response**: JSON array of suggestions
  ```json
  [
    {
      "name": "Lahore",
      "full_address": "Lahore, Punjab, Pakistan"
    }
  ]
  ```

### Frontend Features

- **Debouncing**: 300ms delay to optimize API calls
- **Keyboard Navigation**: Full accessibility support
- **Loading States**: Visual feedback during API requests
- **Error Handling**: Graceful degradation on failures
- **Responsive Design**: Mobile-first approach
- **Smooth Animations**: CSS transitions for better UX

## 🔄 Performance Optimizations

- Debounced input (300ms) to reduce API calls
- Request deduplication - avoids calling API for same query twice
- Async/await for non-blocking API requests
- Efficient DOM manipulation
- CSS animations with GPU acceleration

## 🌐 Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📝 License

This project is for educational/demonstration purposes.

## 🤝 Credits

- **Geocoding API**: [MapTiler](https://www.maptiler.com/)
- **Icons**: Feather Icons
- **Framework**: Flask (Python)

---

**Built with ❤️ using Flask and MapTiler**
