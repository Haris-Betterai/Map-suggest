from flask import Flask, render_template, request, jsonify
import requests
from typing import List, Dict

app = Flask(__name__)

# MapTiler API Configuration
MAPTILER_API_KEY = "DVL1VXFhlCuGm9uEgtP9"
GEOCODING_BASE_URL = "https://api.maptiler.com/geocoding"

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')

@app.route('/autocomplete')
def autocomplete():
    """
    Autocomplete endpoint for address suggestions
    Query params:
        q: search query
    Returns:
        JSON list of suggestions with name and full_address
    """
    query = request.args.get('q', '').strip()
    
    # Handle empty input
    if not query:
        return jsonify([])
    
    try:
        # Build MapTiler API request
        url = f"{GEOCODING_BASE_URL}/{query}.json"
        params = {
            'key': MAPTILER_API_KEY,
            'limit': 5,
            'country': 'pk',
            'autocomplete': 'true',
            "language" : "en"
        }
        
        # Make API request with timeout
        response = requests.get(url, params=params, timeout=5)
        response.raise_for_status()
        
        data = response.json()
        
        # Extract and format suggestions
        suggestions = []
        for feature in data.get('features', []):
            suggestion = {
                'name': feature.get('text', ''),
                'full_address': feature.get('place_name', '')
            }
            suggestions.append(suggestion)
        
        return jsonify(suggestions)
    
    except requests.exceptions.RequestException as e:
        # Log error in production, return empty list to prevent crashes
        print(f"API Error: {e}")
        return jsonify([])
    
    except Exception as e:
        # Catch any other errors
        print(f"Unexpected Error: {e}")
        return jsonify([])

if __name__ == '__main__':
    # Development server
    app.run(debug=True, host='localhost', port=5000)
