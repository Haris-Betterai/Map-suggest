// DOM Elements
const searchInput = document.getElementById('search-input');
const dropdown = document.getElementById('dropdown');
const dropdownList = document.getElementById('dropdown-list');
const loadingSpinner = document.getElementById('loading-spinner');

// State
let currentFocus = -1;
let debounceTimer = null;
let currentQuery = '';
let lastRequestQuery = '';

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeEventListeners();
});

/**
 * Initialize all event listeners
 */
function initializeEventListeners() {
    // Input event with debounce
    searchInput.addEventListener('input', handleInput);
    
    // Keyboard navigation
    searchInput.addEventListener('keydown', handleKeyDown);
    
    // Click outside to close dropdown
    document.addEventListener('click', handleClickOutside);
    
    // Prevent form submission on Enter
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
        }
    });
}

/**
 * Handle input event with debounce
 */
function handleInput(e) {
    const query = e.target.value.trim();
    currentQuery = query;
    
    // Clear previous timer
    if (debounceTimer) {
        clearTimeout(debounceTimer);
    }
    
    // If input is empty, hide dropdown immediately
    if (!query) {
        hideDropdown();
        hideLoading();
        return;
    }
    
    // Show loading spinner
    showLoading();
    
    // Debounce API call (300ms)
    debounceTimer = setTimeout(() => {
        fetchSuggestions(query);
    }, 300);
}

/**
 * Fetch suggestions from the backend
 */
async function fetchSuggestions(query) {
    // Avoid duplicate requests
    if (query === lastRequestQuery) {
        return;
    }
    
    lastRequestQuery = query;
    
    try {
        const response = await fetch(`/autocomplete?q=${encodeURIComponent(query)}`);
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const suggestions = await response.json();
        
        // Only update if the query hasn't changed
        if (query === currentQuery) {
            displaySuggestions(suggestions, query);
            hideLoading();
        }
        
    } catch (error) {
        console.error('Error fetching suggestions:', error);
        hideLoading();
        showNoResults();
    }
}

/**
 * Display suggestions in dropdown
 */
function displaySuggestions(suggestions, query) {
    // Clear previous suggestions
    dropdownList.innerHTML = '';
    currentFocus = -1;
    
    if (suggestions.length === 0) {
        showNoResults();
        return;
    }
    
    // Create suggestion items
    suggestions.forEach((suggestion, index) => {
        const item = createSuggestionItem(suggestion, query, index);
        dropdownList.appendChild(item);
    });
    
    showDropdown();
}

/**
 * Create a suggestion item element
 */
function createSuggestionItem(suggestion, query, index) {
    const item = document.createElement('div');
    item.className = 'suggestion-item';
    item.dataset.index = index;
    
    // Highlight matching text in name
    const highlightedName = highlightMatch(suggestion.name, query);
    
    item.innerHTML = `
        <div class="suggestion-name">${highlightedName}</div>
        <div class="suggestion-address">${escapeHtml(suggestion.full_address)}</div>
    `;
    
    // Click event
    item.addEventListener('click', () => {
        selectSuggestion(suggestion);
    });
    
    // Mouse enter event
    item.addEventListener('mouseenter', () => {
        removeActiveClass();
        item.classList.add('active');
        currentFocus = index;
    });
    
    return item;
}

/**
 * Highlight matching text in the string
 */
function highlightMatch(text, query) {
    const escapedText = escapeHtml(text);
    const escapedQuery = escapeHtml(query);
    
    // Case-insensitive replace
    const regex = new RegExp(`(${escapedQuery})`, 'gi');
    return escapedText.replace(regex, '<span class="highlight">$1</span>');
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Select a suggestion
 */
function selectSuggestion(suggestion) {
    searchInput.value = suggestion.full_address;
    hideDropdown();
    
    // Optional: You could emit an event here for further processing
    console.log('Selected:', suggestion);
}

/**
 * Show "No results found" message
 */
function showNoResults() {
    dropdownList.innerHTML = `
        <div class="no-results">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.35-4.35"></path>
            </svg>
            <div>No results found</div>
        </div>
    `;
    showDropdown();
}

/**
 * Handle keyboard navigation
 */
function handleKeyDown(e) {
    const items = dropdownList.querySelectorAll('.suggestion-item');
    
    if (!items.length) return;
    
    switch(e.key) {
        case 'ArrowDown':
            e.preventDefault();
            currentFocus++;
            if (currentFocus >= items.length) currentFocus = 0;
            setActiveItem(items);
            break;
            
        case 'ArrowUp':
            e.preventDefault();
            currentFocus--;
            if (currentFocus < 0) currentFocus = items.length - 1;
            setActiveItem(items);
            break;
            
        case 'Enter':
            e.preventDefault();
            if (currentFocus > -1 && items[currentFocus]) {
                items[currentFocus].click();
            }
            break;
            
        case 'Escape':
            e.preventDefault();
            hideDropdown();
            break;
    }
}

/**
 * Set active item based on currentFocus
 */
function setActiveItem(items) {
    removeActiveClass();
    
    if (currentFocus >= 0 && currentFocus < items.length) {
        items[currentFocus].classList.add('active');
        items[currentFocus].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
}

/**
 * Remove active class from all items
 */
function removeActiveClass() {
    const items = dropdownList.querySelectorAll('.suggestion-item');
    items.forEach(item => item.classList.remove('active'));
}

/**
 * Handle click outside dropdown
 */
function handleClickOutside(e) {
    if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
        hideDropdown();
    }
}

/**
 * Show dropdown
 */
function showDropdown() {
    dropdown.classList.add('active');
}

/**
 * Hide dropdown
 */
function hideDropdown() {
    dropdown.classList.remove('active');
    currentFocus = -1;
}

/**
 * Show loading spinner
 */
function showLoading() {
    loadingSpinner.classList.add('active');
}

/**
 * Hide loading spinner
 */
function hideLoading() {
    loadingSpinner.classList.remove('active');
}
